#!/bin/bash
# chmod +x teste.sh
# ./teste.sh ajustePolv1 ajustePolv2 3


# Vetores para os testes (Dois vetores)

# para posterior geração de gráficos.

# Argumentos de entrada:
# $1: Caminho para o programa ajustePolv1
# $2: Caminho para o programa ajustePolv2
# $3: Core da CPU a ser utilizada para os testes com LIKWID (ex: 3)

N=(10 1000)
K=(64 128 200 256 512 600 800 1024 2000 3000 4096 6000 7000 10000 50000 100000 1000000 10000000 100000000)

LIKWID_CMD="likwid-perfctr -m -C $3 -g"


# CONFIGURA A CPU PARA COM A PERFORMACE CORRETA
echo "performance" > /sys/devices/system/cpu/cpufreq/policy3/scaling_governor

# limpeza
rm -f *.dat


# Arquivos usados para gerar o grafico depois
temp_files=(auxiliar_tempo.dat auxiliar_l3cache.dat auxiliar_energy.dat auxiliar_flops_dp.dat auxiliar_flops_avx_dp.dat)


for k in "${K[@]}"
do
    echo "Analisando K=$k..."

    # Adiciona o valor de K nos arquivos de saída
    for file in "${temp_files[@]}"; do
        echo -n "$k " >> $file
    done

    for n in "${N[@]}"
    do
        # Pula o caso K > 100000 e N = 1000
        if [[ $k -gt 100000 && $n -eq 1000 ]]; then
            continue
        fi

        echo "  Analisando para N=$n..."

        # Gera entrada
        ./gera_entrada $k $n > entrada.dat

        # Função para medir desempenho com LIKWID
        function measure() {
            local metric=$1
            local program=$2
            cat entrada.dat | likwid-perfctr -C 3 -g $metric -m ./$program
        }


        # CACHE ENTRE OS DOIS CODIGOS 
        for prog in $1 $2; do 
            measure L3CACHE $prog |
                awk -F'|' 'BEGIN {ORS=" "}; $2 ~ /L3 miss ratio/ {gsub (" ", "", $3); print $3}' >> auxiliar_l3cache.dat
        done


        # CALCULO DA ENERGIA ENTRE CODIGOS 
        for prog in $1 $2; do 
            measure ENERGY $prog |
                awk -F'|' '$2 ~ /Energy/ {gsub (" ", "", $3); print $3}' |
                awk 'BEGIN {ORS=" "}; (NR-1) % 4 == 0 {print}' >> auxiliar_energy.dat
        done


        # CALCULO DE FLOPS AVX PARA OS DOIS CODIGOS
        for prog in $1 $2; do 
            measure FLOPS_DP $prog > temp.dat
            awk -F'|' '$2 ~ /DP/ {print $2 $3}' temp.dat |
                awk 'BEGIN {ORS=" "}; $1 !~ /AVX/ {print $3}' >> auxiliar_flops_dp.dat
            awk -F'|' 'BEGIN {ORS=" "}; $2 ~ /AVX/ {gsub (" ", "", $3); print $3}' temp.dat >> auxiliar_flops_avx_dp.dat
            awk 'BEGIN {ORS=" "}; NR == 8 {print $2, $3}' temp.dat >> auxiliar_tempo.dat
        done

        rm -f entrada.dat
        echo "  Concluído."
    done

    
    for file in "${temp_files[@]}"; do
        echo "" >> $file
    done

done



# Limpeza
echo "powersave" > /sys/devices/system/cpu/cpufreq/policy3/scaling_governor
rm -f temp.dat

echo "Testes concluídos."