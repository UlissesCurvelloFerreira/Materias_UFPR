#!/usr/bin/gnuplot -c

set encoding utf
set xlabel "Num de Pontos"
set grid
set style data points
set style function lines
set xtics
set boxwidth 1
set style line 2 lc 3 pt 7 ps 0.3
set datafile separator " "
set logscale x

# ===========================TEMPO====================================

# Plot de Tempo (Log Y)
set ylabel "Tempo"
set logscale y

set title "TEMPO DE MQ"
set terminal qt 0 title "TEMPO DE MQ"
plot 'auxiliar_tempo.dat' using 1:2 title "N1+v1" with linespoints, \
     '' using 1:6 title "N2+v1" with linespoints, \
     '' using 1:4 title "N1+v2" with linespoints, \
     '' using 1:8 title "N2+v2" with linespoints
pause -1

set title "TEMPO DE EG"
set terminal qt 0 title "TEMPO DE EG"
plot 'auxiliar_tempo.dat' using 1:3 title "N1+v1" with linespoints, \
     '' using 1:7 title "N2+v1" with linespoints, \
     '' using 1:5 title "N1+v2" with linespoints, \
     '' using 1:9 title "N2+v2" with linespoints
pause -1

unset logscale y

# ==========================CACHE=====================================

set title "CACHE MISS L3 DE MQ"
set terminal qt 0 title "CACHE MISS L3 DE MQ"
plot 'auxiliar_l3cache.dat' using 1:2 title "N1+v1" with linespoints, \
     '' using 1:6 title "N2+v1" with linespoints, \
     '' using 1:4 title "N1+v2" with linespoints, \
     '' using 1:8 title "N2+v2" with linespoints
pause -1

set title "CACHE MISS L3 DE EG"
set terminal qt 0 title "CACHE MISS L3 DE EG"
plot 'auxiliar_l3cache.dat' using 1:3 title "N1+v1" with linespoints, \
     '' using 1:7 title "N2+v1" with linespoints, \
     '' using 1:5 title "N1+v2" with linespoints, \
     '' using 1:9 title "N2+v2" with linespoints
pause -1

# ===========================ENERGIA====================================

set title "ENERGIA DE MQ"
set terminal qt 0 title "ENERGIA DE MQ"
plot 'auxiliar_energy.dat' using 1:2 title "N1+v1" with linespoints, \
     '' using 1:6 title "N2+v1" with linespoints, \
     '' using 1:4 title "N1+v2" with linespoints, \
     '' using 1:8 title "N2+v2" with linespoints
pause -1

set title "ENERGIA DE EG"
set terminal qt 0 title "ENERGIA DE EG"
plot 'auxiliar_energy.dat' using 1:3 title "N1+v1" with linespoints, \
     '' using 1:7 title "N2+v1" with linespoints, \
     '' using 1:5 title "N1+v2" with linespoints, \
     '' using 1:9 title "N2+v2" with linespoints
pause -1

# ===========================FLOPS====================================

set title "FLOPS DP DE MQ"
set terminal qt 0 title "FLOPS DP DE MQ"
plot 'auxiliar_flops_dp.dat' using 1:2 title "N1+v1" with linespoints, \
     '' using 1:6 title "N2+v1" with linespoints, \
     '' using 1:4 title "N1+v2" with linespoints, \
     '' using 1:8 title "N2+v2" with linespoints
pause -1

set title "FLOPS DP DE EG"
set terminal qt 0 title "FLOPS DP DE EG"
plot 'auxiliar_flops_dp.dat' using 1:3 title "N1+v1" with linespoints, \
     '' using 1:7 title "N2+v1" with linespoints, \
     '' using 1:5 title "N1+v2" with linespoints, \
     '' using 1:9 title "N2+v2" with linespoints
pause -1

# ===============================================================

set title "FLOPS AVX DP EM MQ"
set terminal qt 0 title "FLOPS AVX DP EM MQ"
plot 'auxiliar_flops_avx_dp.dat' using 1:2 title "N1+v1" with linespoints, \
     '' using 1:6 title "N2+v1" with linespoints, \
     '' using 1:4 title "N1+v2" with linespoints, \
     '' using 1:8 title "N2+v2" with linespoints
pause -1

set title "FLOPS AVX DP EM EG"
set terminal qt 0 title "FLOPS AVX DP EM EG"
plot 'auxiliar_flops_avx_dp.dat' using 1:3 title "N1+v1" with linespoints, \
     '' using 1:7 title "N2+v1" with linespoints, \
     '' using 1:5 title "N1+v2" with linespoints, \
     '' using 1:9 title "N2+v2" with linespoints
pause -1

# ===============================================================
