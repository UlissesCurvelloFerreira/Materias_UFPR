# Pedro Henrique Gurski de Oliveira | GRR: 20224759
# Ulisses Curvello Ferreira         | GRR: 20223829

# Compilar
gcc -std=c11 -Wall -Wextra -o fdtool main.c
ou
make

# Testar
./fdtool closure --fds exemplos/e1.fds --X A
./fdtool mincover --fds exemplos/e1.fds
./fdtool keys --fds exemplos/e1.fds
./fdtool normalform --fds exemplos/e3.fds

# Exemplos
Os exemplos estão na pasta exemplos com os nomes: e1.fds, e2.fds, ..., e12.fds

# Referencias
Slides Professora Simone
https://wiki.inf.ufpr.br/maziero/doku.php?id=c:operacoes_com_bits
https://www.codemarathon.com.br/conteudos/matematica/manipulacao-de-bits