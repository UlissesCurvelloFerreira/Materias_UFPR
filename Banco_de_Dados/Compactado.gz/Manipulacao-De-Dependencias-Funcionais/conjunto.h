#ifndef CONJUNTO_H
#define CONJUNTO_H

#include <stdbool.h>

// Colocamos max 20 para nao estourar memoria, porem o certo para o problema seria 26
#define MAX_ATRIBUTOS 20

// Conjunto de atributos como bitmap
typedef struct {
    unsigned int bits; // cada bit representa um atributo A-Z
} ConjuntoAtributos;

// Funções de manipulação de conjuntos
ConjuntoAtributos conjunto_vazio();
void adicionar_atributo(ConjuntoAtributos *conjunto, char atributo);
bool contem_atributo(ConjuntoAtributos conjunto, char atributo);
bool eh_subconjunto(ConjuntoAtributos a, ConjuntoAtributos b);
bool sao_iguais(ConjuntoAtributos a, ConjuntoAtributos b);
ConjuntoAtributos uniao_conjuntos(ConjuntoAtributos a, ConjuntoAtributos b);
ConjuntoAtributos diferenca_conjuntos(ConjuntoAtributos a, ConjuntoAtributos b);
bool eh_vazio(ConjuntoAtributos conjunto);
int contar_atributos(ConjuntoAtributos conjunto);
void imprime_conjunto(ConjuntoAtributos conjunto);
ConjuntoAtributos decompor_atributos(const char *str);

#endif