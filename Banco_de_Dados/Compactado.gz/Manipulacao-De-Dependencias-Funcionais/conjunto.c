#include "conjunto.h"
#include <stdio.h>

ConjuntoAtributos conjunto_vazio() {
    ConjuntoAtributos s = {0};
    return s;
}

/* Adiciona um atributo a um conjunto de atributos, usando bits.
   Cada bit representa a presença (1) ou ausência (0) de um atributo. */
void adicionar_atributo(ConjuntoAtributos *conjunto, char atributo) {
    if (atributo >= 'A' && atributo <= 'Z') {
        conjunto->bits |= (1u << (atributo - 'A'));
    }
}
/* Verifica se um atributo pertence ao conjunto de atributos */
bool contem_atributo(ConjuntoAtributos conjunto, char atributo) {
    if (atributo >= 'A' && atributo <= 'Z') {
        return (conjunto.bits & (1u << (atributo - 'A'))) != 0;
    }
    return false;
}

/* Verifica se um conjunto a eh subconjunto de outro conjunto b */
bool eh_subconjunto(ConjuntoAtributos a, ConjuntoAtributos b) {
    return (a.bits & b.bits) == a.bits;
}

/* Verifica se um conjunto a eh igual a outro conjunto b */
bool sao_iguais(ConjuntoAtributos a, ConjuntoAtributos b) {
    return a.bits == b.bits;
}

/* Une dois conjuntos */
ConjuntoAtributos uniao_conjuntos(ConjuntoAtributos a, ConjuntoAtributos b) {
    ConjuntoAtributos resultado = {a.bits | b.bits};
    return resultado;
}

/* Retorna um novo conjunto que contem todos os atributos que estão em a, mas não estão em b */
ConjuntoAtributos diferenca_conjuntos(ConjuntoAtributos a, ConjuntoAtributos b) {
    ConjuntoAtributos resultado = {a.bits & ~b.bits};
    return resultado;
}

/* Verifica se um conjunto eh vazio */
bool eh_vazio(ConjuntoAtributos conjunto) {
    return conjunto.bits == 0;
}

/* conta quantos atributos estao presentes no conjunto */
int contar_atributos(ConjuntoAtributos conjunto) {
    int contagem = 0;
    for (int i = 0; i < MAX_ATRIBUTOS; i++) {
        if (conjunto.bits & (1u << i)) contagem++;
    }
    return contagem;
}

void imprime_conjunto(ConjuntoAtributos conjunto) {
    for (int i = 0; i < MAX_ATRIBUTOS; i++) {
        if (conjunto.bits & (1u << i)) {
            printf("%c", 'A' + i);
        }
    }
}

/* Converte uma string em um conjunto de atributos */
ConjuntoAtributos decompor_atributos(const char *str) {
    ConjuntoAtributos conjunto = conjunto_vazio();
    for (int i = 0; str[i]; i++) {
        if (str[i] >= 'A' && str[i] <= 'Z') {
            adicionar_atributo(&conjunto, str[i]);
        }
    }
    return conjunto;
}