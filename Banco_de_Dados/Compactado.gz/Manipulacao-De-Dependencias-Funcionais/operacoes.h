#ifndef OPERACOES_H
#define OPERACOES_H

// X+ de um conjunto de atributos X contido em U dado F
void calcula_fecho(const char *arquivo_fds, const char *str_x);

// F (RHS unitario, remocaoo de atributos estranhos e DFs redundantes)
void cobertura_minima(const char *arquivo_fds);

// Todas as minimas K tais que K+ = U
void chaves_candidatas(const char *arquivo_fds);

// BCNF e 3FN.
void verif_formas_normais(const char *arquivo_fds);

#endif