#ifndef ESQUEMA_H
#define ESQUEMA_H

#include "conjunto.h"
#include <stdbool.h>

#define MAX_DFS 100

// Dependência Funcional (DF)
typedef struct {
    ConjuntoAtributos lhs; // Left-Hand Side
    ConjuntoAtributos rhs; // Right-Hand Side
} DF;

// Esquema relacional
typedef struct {
    ConjuntoAtributos atributos; // Universo U de atributos
    DF dfs[MAX_DFS];             // Conjunto F de dependências funcionais
    int num_dfs;                 // Quantidade de DFs
} Esquema;

bool carregar_arquivo_fds(const char *nome_arquivo, Esquema *esquema);
ConjuntoAtributos calcular_fecho(ConjuntoAtributos x, DF *dfs, int num_dfs);

#endif