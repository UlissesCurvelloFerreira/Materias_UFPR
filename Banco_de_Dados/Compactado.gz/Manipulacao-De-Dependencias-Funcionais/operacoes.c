#include "operacoes.h"
#include "esquema.h"
#include "conjunto.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void calcula_fecho(const char *arquivo_fds, const char *str_x) {
    Esquema esquema;
    if (!carregar_arquivo_fds(arquivo_fds, &esquema)) {
        fprintf(stderr, "Erro ao carregar arquivo de DFs\n");
        return;
    }

    ConjuntoAtributos x = decompor_atributos(str_x);
    ConjuntoAtributos resultado = calcular_fecho(x, esquema.dfs, esquema.num_dfs);
    imprime_conjunto(resultado);
    printf("\n");
}

void cobertura_minima(const char *arquivo_fds) {
    Esquema esquema;
    if (!carregar_arquivo_fds(arquivo_fds, &esquema)) {
        fprintf(stderr, "Erro ao carregar arquivo de DFs\n");
        return;
    }

    DF cobertura[MAX_DFS * MAX_ATRIBUTOS];
    int num_cobertura = 0;

    // Decompor RHS
    for (int i = 0; i < esquema.num_dfs; i++) {
        for (int j = 0; j < MAX_ATRIBUTOS; j++) {
            if (esquema.dfs[i].rhs.bits & (1u << j)) {
                cobertura[num_cobertura].lhs = esquema.dfs[i].lhs;
                cobertura[num_cobertura].rhs = conjunto_vazio();
                cobertura[num_cobertura].rhs.bits = (1u << j);
                num_cobertura++;
            }
        }
    }

    // Remover atributos estranhos no LHS
    for (int i = 0; i < num_cobertura; i++) {
        for (int j = 0; j < MAX_ATRIBUTOS; j++) {
            if (cobertura[i].lhs.bits & (1u << j)) {
                ConjuntoAtributos novo_lhs = cobertura[i].lhs;
                novo_lhs.bits &= ~(1u << j);
                
                if (!eh_vazio(novo_lhs)) {
                    ConjuntoAtributos fecho = calcular_fecho(novo_lhs, cobertura, num_cobertura);
                    if (eh_subconjunto(cobertura[i].rhs, fecho)) {
                        cobertura[i].lhs = novo_lhs;
                    }
                }
            }
        }
    }

    // Remover DFs redundantes
    bool removida[MAX_DFS * MAX_ATRIBUTOS] = {false};
    for (int i = 0; i < num_cobertura; i++) {
        DF temp[MAX_DFS * MAX_ATRIBUTOS];
        int contagem_temp = 0;
        
        for (int j = 0; j < num_cobertura; j++) {
            if (i != j && !removida[j]) {
                temp[contagem_temp++] = cobertura[j];
            }
        }
        
        ConjuntoAtributos fecho = calcular_fecho(cobertura[i].lhs, temp, contagem_temp);
        if (eh_subconjunto(cobertura[i].rhs, fecho)) {
            removida[i] = true;
        }
    }

    // Imprime a cobertura minima
    for (int i = 0; i < num_cobertura; i++) {
        if (!removida[i]) {
            imprime_conjunto(cobertura[i].lhs);
            printf("->");
            imprime_conjunto(cobertura[i].rhs);
            printf("\n");
        }
    }
}

void chaves_candidatas(const char *arquivo_fds) {
    Esquema esquema;
    if (!carregar_arquivo_fds(arquivo_fds, &esquema)) {
        fprintf(stderr, "Erro ao carregar arquivo de DFs\n");
        return;
    }

    int num_atributos = contar_atributos(esquema.atributos);
    
    // Colocamos isso para nao estourar a memoria
    if (num_atributos > MAX_ATRIBUTOS) {
        fprintf(stderr, "Erro: Muitos atributos (%d). Máximo suportado: %d\n", num_atributos, MAX_ATRIBUTOS);
        return;
    }
    
    int max_combinacoes = 1 << num_atributos;

    // Encontra atributos essenciais
    ConjuntoAtributos no_rhs = conjunto_vazio();
    for (int i = 0; i < esquema.num_dfs; i++) {
        no_rhs = uniao_conjuntos(no_rhs, esquema.dfs[i].rhs);
    }
    ConjuntoAtributos essenciais = diferenca_conjuntos(esquema.atributos, no_rhs);

    // Aloca arrays menores dependendo do numero real de atributos
    ConjuntoAtributos *fila = malloc(max_combinacoes * sizeof(ConjuntoAtributos));
    bool *visitado = calloc(max_combinacoes, sizeof(bool));
    ConjuntoAtributos *chaves = malloc(max_combinacoes * sizeof(ConjuntoAtributos));
    
    if (!fila || !visitado || !chaves) {
        fprintf(stderr, "Erro ao alocar memoriaa\n");
        free(fila);
        free(visitado);
        free(chaves);
        return;
    }

    int frente = 0, tras = 0;
    int num_chaves = 0;

    // Mapeia bits do esquema para indices sequenciais
    int bit_to_index[MAX_ATRIBUTOS] = {0};
    int idx = 0;
    for (int i = 0; i < MAX_ATRIBUTOS; i++) {
        if (esquema.atributos.bits & (1u << i)) {
            bit_to_index[i] = idx;
            idx++;
        }
    }

    // converte conjunto para indice na fila
    unsigned int idx_essenciais = 0;
    for (int i = 0; i < MAX_ATRIBUTOS; i++) {
        if (essenciais.bits & (1u << i)) {
            idx_essenciais |= (1u << bit_to_index[i]);
        }
    }
    
    fila[tras++] = essenciais;
    visitado[idx_essenciais] = true;

    while (frente < tras) {
        ConjuntoAtributos atual = fila[frente++];
        ConjuntoAtributos fecho = calcular_fecho(atual, esquema.dfs, esquema.num_dfs);

        if (sao_iguais(fecho, esquema.atributos)) {
            chaves[num_chaves++] = atual;
        } else {
            for (int i = 0; i < MAX_ATRIBUTOS; i++) {
                if ((esquema.atributos.bits & (1u << i)) && !(atual.bits & (1u << i))) {
                    ConjuntoAtributos proximo = atual;
                    proximo.bits |= (1u << i);
                    
                    // Converte conjunto para índice
                    unsigned int idx_proximo = 0;
                    for (int j = 0; j < MAX_ATRIBUTOS; j++) {
                        if ((esquema.atributos.bits & (1u << j)) && (proximo.bits & (1u << j))) {
                            idx_proximo |= (1u << bit_to_index[j]);
                        }
                    }

                    if (!visitado[idx_proximo]) {
                        visitado[idx_proximo] = true;
                        fila[tras++] = proximo;
                    }
                }
            }
        }
    }

    // Filtra apenas chaves minimas
    for (int i = 0; i < num_chaves; i++) {
        bool eh_minimal = true;
        for (int j = 0; j < num_chaves; j++) {
            if (i != j && eh_subconjunto(chaves[j], chaves[i]) && !sao_iguais(chaves[i], chaves[j])) {
                eh_minimal = false;
                break;
            }
        }
        if (eh_minimal) {
            imprime_conjunto(chaves[i]);
            printf("\n");
        }
    }

    free(fila);
    free(visitado);
    free(chaves);
}

void verif_formas_normais(const char *arquivo_fds) {
    Esquema esquema;
    if (!carregar_arquivo_fds(arquivo_fds, &esquema)) {
        fprintf(stderr, "Erro ao carregarr arquivo de DFs\n");
        return;
    }

    // Calcular cobertura minima unitaria
    DF cobertura[MAX_DFS * MAX_ATRIBUTOS];
    int num_cobertura = 0;

    for (int i = 0; i < esquema.num_dfs; i++) {
        for (int j = 0; j < MAX_ATRIBUTOS; j++) {
            if (esquema.dfs[i].rhs.bits & (1u << j)) {
                cobertura[num_cobertura].lhs = esquema.dfs[i].lhs;
                cobertura[num_cobertura].rhs = conjunto_vazio();
                cobertura[num_cobertura].rhs.bits = (1u << j);
                num_cobertura++;
            }
        }
    }

    // Calcula atributos primos
    ConjuntoAtributos no_rhs = conjunto_vazio();
    for (int i = 0; i < esquema.num_dfs; i++) {
        no_rhs = uniao_conjuntos(no_rhs, esquema.dfs[i].rhs);
    }

    ConjuntoAtributos atributos_primos = conjunto_vazio();

    // Gera todas as chaves candidatas
    ConjuntoAtributos chaves[MAX_DFS];
    int num_chaves = 0;

    for (unsigned int mask = 1; mask < (1u << MAX_ATRIBUTOS); mask++) {
        ConjuntoAtributos conjunto = {mask};
        if (eh_subconjunto(conjunto, esquema.atributos)) {
            ConjuntoAtributos fecho = calcular_fecho(conjunto, esquema.dfs, esquema.num_dfs);
            if (sao_iguais(fecho, esquema.atributos)) {
                bool minimal = true;
                for (int j = 0; j < num_chaves; j++) {
                    if (eh_subconjunto(chaves[j], conjunto)) {
                        minimal = false;
                        break;
                    }
                }
                if (minimal) chaves[num_chaves++] = conjunto;
            }
        }
    }

    // Atributos presentes em alguma chave sao primos
    for (int i = 0; i < num_chaves; i++) {
        atributos_primos = uniao_conjuntos(atributos_primos, chaves[i]);
    }

    bool bcnf_ok = true, nf3_ok = true;
    char violacoes[MAX_DFS * MAX_ATRIBUTOS][256];
    int num_violacoes = 0;

    // Verifica cada DF da cobertura minima
    for (int i = 0; i < num_cobertura; i++) {
        if (eh_subconjunto(cobertura[i].rhs, cobertura[i].lhs)) continue;

        ConjuntoAtributos fecho_lhs = calcular_fecho(cobertura[i].lhs, esquema.dfs, esquema.num_dfs);
        bool eh_superchave = sao_iguais(fecho_lhs, esquema.atributos);

        if (!eh_superchave) {
            char atributo_rhs = 0;
            for (int j = 0; j < MAX_ATRIBUTOS; j++) {
                if (cobertura[i].rhs.bits & (1u << j)) {
                    atributo_rhs = 'A' + j;
                    break;
                }
            }
            
            bool rhs_eh_primo = contem_atributo(atributos_primos, atributo_rhs);

            bcnf_ok = false;
            sprintf(violacoes[num_violacoes++], "VIOLATION BCNF: ");
            int tam = strlen(violacoes[num_violacoes-1]);
            for (int k = 0; k < MAX_ATRIBUTOS; k++) {
                if (cobertura[i].lhs.bits & (1u << k)) {
                    violacoes[num_violacoes-1][tam++] = 'A' + k;
                }
            }
            sprintf(violacoes[num_violacoes-1] + tam, "->%c (", atributo_rhs);
            tam = strlen(violacoes[num_violacoes-1]);
            for (int k = 0; k < MAX_ATRIBUTOS; k++) {
                if (cobertura[i].lhs.bits & (1u << k)) {
                    violacoes[num_violacoes-1][tam++] = 'A' + k;
                }
            }
            sprintf(violacoes[num_violacoes-1] + tam, " not superkey)");
            
            if (!rhs_eh_primo) {
                nf3_ok = false;
                sprintf(violacoes[num_violacoes++], "VIOLATION 3NF: ");
                tam = strlen(violacoes[num_violacoes-1]);
                for (int k = 0; k < MAX_ATRIBUTOS; k++) {
                    if (cobertura[i].lhs.bits & (1u << k)) {
                        violacoes[num_violacoes-1][tam++] = 'A' + k;
                    }
                }
                sprintf(violacoes[num_violacoes-1] + tam, "->%c (%c not prime, ", atributo_rhs, atributo_rhs);
                tam = strlen(violacoes[num_violacoes-1]);
                for (int k = 0; k < MAX_ATRIBUTOS; k++) {
                    if (cobertura[i].lhs.bits & (1u << k)) {
                        violacoes[num_violacoes-1][tam++] = 'A' + k;
                    }
                }
                sprintf(violacoes[num_violacoes-1] + tam, " not superkey)");
            }
        }
    }

    printf("BCNF: %s\n", bcnf_ok ? "OK" : "VIOLATIONS");
    printf("3NF: %s\n", nf3_ok ? "OK" : "VIOLATIONS");
    
    for (int i = 0; i < num_violacoes; i++) {
        printf("%s\n", violacoes[i]);
    }
}