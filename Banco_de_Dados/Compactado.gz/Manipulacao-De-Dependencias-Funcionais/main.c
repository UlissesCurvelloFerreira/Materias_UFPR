#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "operacoes.h"

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Erro de execucao, olhe o README para executar corretamente\n");
        return 1;
    }

    const char *comando = argv[1];

    if (strcmp(comando, "closure") == 0) {
        if (argc < 6) {
            fprintf(stderr, "Erro de execucao: fdtool closure --fds <arquivo> --X <atributos>\n");
            return 1;
        }
        const char *arquivo_fds = argv[3];
        const char *str_x = argv[5];
        calcula_fecho(arquivo_fds, str_x);
    }
    else if (strcmp(comando, "mincover") == 0) {
        if (argc < 4) {
            fprintf(stderr, "Uso: fdtool mincover --fds <arquivo>\n");
            return 1;
        }
        cobertura_minima(argv[3]);
    }
    else if (strcmp(comando, "keys") == 0) {
        if (argc < 4) {
            fprintf(stderr, "Uso: fdtool keys --fds <arquivo>\n");
            return 1;
        }
        chaves_candidatas(argv[3]);
    }
    else if (strcmp(comando, "normalform") == 0) {
        if (argc < 4) {
            fprintf(stderr, "Uso: fdtool normalform --fds <arquivo>\n");
            return 1;
        }
        verif_formas_normais(argv[3]);
    }
    else {
        fprintf(stderr, "Comando desconhecido: %s\n", comando);
        fprintf(stderr, "Use: closure, mincover, keys ou normalform\n");
        return 1;
    }

    return 0;
}