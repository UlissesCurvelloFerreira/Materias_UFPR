#include "esquema.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LINHA 1024

bool carregar_arquivo_fds(const char *nome_arquivo, Esquema *esquema) {
    FILE *arquivo = fopen(nome_arquivo, "r");
    if (!arquivo) {
        fprintf(stderr, "Erro ao abrir arquivo: %s\n", nome_arquivo);
        return false;
    }

    char linha[MAX_LINHA];
    esquema->atributos = conjunto_vazio();
    esquema->num_dfs = 0;

    while (fgets(linha, sizeof(linha), arquivo)) {
        // Remove comentários (#)
        char *comentario = strchr(linha, '#');
        if (comentario) *comentario = '\0';

        // Parseia U
        if (strstr(linha, "U") && strchr(linha, '=')) {
            char *inicio = strchr(linha, '{');
            char *fim = strchr(linha, '}');
            if (inicio && fim) {
                inicio++;
                while (inicio < fim) {
                    if (*inicio >= 'A' && *inicio <= 'Z') {
                        adicionar_atributo(&esquema->atributos, *inicio);
                    }
                    inicio++;
                }
            }
        }

        // Parseia F
        if (strstr(linha, "F") && strchr(linha, '=')) {
            char *inicio = strchr(linha, '{');
            char *fim = strrchr(linha, '}');
            if (inicio && fim) {
                inicio++;
                char *token = strtok(inicio, ",;");
                while (token && esquema->num_dfs < MAX_DFS) {
                    char *seta = strstr(token, "->");
                    if (seta) {
                        *seta = '\0';
                        ConjuntoAtributos lhs = decompor_atributos(token);
                        ConjuntoAtributos rhs = decompor_atributos(seta + 2);
                        
                        // Adiciona a DF se os dois lados não forem vazios
                        if (!eh_vazio(lhs) && !eh_vazio(rhs)) {
                            esquema->dfs[esquema->num_dfs].lhs = lhs;
                            esquema->dfs[esquema->num_dfs].rhs = rhs;
                            esquema->num_dfs++;
                        }
                    }
                    token = strtok(NULL, ",;");
                }
            }
        }
    }

    fclose(arquivo);
    return esquema->num_dfs > 0;
}

ConjuntoAtributos calcular_fecho(ConjuntoAtributos x, DF *dfs, int num_dfs) {
    ConjuntoAtributos resultado = x;
    bool alterado = true;
    
    while (alterado) {
        alterado = false;
        for (int i = 0; i < num_dfs; i++) {
            // Se L estah contido em resultado e R não estah contido resultado, entao resultado = resultado uniao R
            if (eh_subconjunto(dfs[i].lhs, resultado) && !eh_subconjunto(dfs[i].rhs, resultado)) {
                resultado = uniao_conjuntos(resultado, dfs[i].rhs);
                alterado = true;
            }
        }
    }
    
    return resultado;
}