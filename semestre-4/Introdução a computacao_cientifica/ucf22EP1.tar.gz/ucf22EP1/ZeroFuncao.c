#include <stdio.h>
#include <math.h>

#include "utils.h"
#include "ZeroFuncao.h"
# include "DoubleType.h"

// Retorna a diferença em ULPs entre dois números reais.
Double_t ulps_diff(real_t a, real_t b) {
    Double_t valorA, valorB;

    valorA.f = a;
    valorB.f = b;
    valorA.i -= valorB.i;
    valorA.i = labs(valorA.i);
    return valorA;
}

// Função baseada nos slides do professor
void calcPolinomio_rapido(Polinomio p, real_t x, real_t *px, real_t *dpx) {
    *px = 0;   
    *dpx = 0;  

    for (int i = p.grau; i > 0; --i) {
        *px = (*px * x) + p.p[i];  
        *dpx = (*dpx * x) + *px; 
    }
    *px = (*px * x) + p.p[0];  
}

// Função baseada nos slides do professor
void calcPolinomio_lento(Polinomio p, real_t x, real_t *px, real_t *dpx) {
    *px = 0;   
    *dpx = 0; 

    for (int i = p.grau; i > 0; --i) {
        *px += p.p[i] * pow(x, i); 
        *dpx += i * p.p[i] * pow(x, i - 1); 
    }
    *px += p.p[0] * pow(x, 0); 
}


// Aplica o método de Newton-Raphson para encontrar a raiz de um polinômio com critério de parada ajustável.
real_t newtonRaphson(Polinomio p, real_t x0, int criterioParada, int *it, real_t *raiz, int modo) {
    real_t fx, dfx, x, erro, x_new;
    Double_t ulps;

    void (*calcPolinomio)(Polinomio, real_t, real_t*, real_t*);
    if (modo == 1) calcPolinomio = calcPolinomio_lento;
    else calcPolinomio = calcPolinomio_rapido;

    x = x0;  // Inicializa x com x0

    *it = 1; // inicializa o contador
    while (*it < MAXIT) {
        calcPolinomio(p, x, &fx, &dfx);

        x_new = x - fx / dfx;
        erro = fabs(x_new - x);
        *raiz = x_new;

        ulps = ulps_diff(x_new, x);

        if (criterioParada == 1 && erro <= EPS) 
            return erro;
        if (criterioParada == 2 && fabs(fx) <= DBL_EPSILON) 
            return fabs(fx);
        if (criterioParada == 3 && ulps.i <= ULPS) 
            return ulps.f;

        x = x_new;  // Atualiza x para a próxima iteração
        (*it)++;
    }

    // Retorno final caso nenhum critério de parada seja satisfeito dentro do limite
    if (criterioParada == 1) 
        return erro;
    if (criterioParada == 2) 
        return fabs(fx);
    if (criterioParada == 3) 
        return ulps.f;

    return -1; // fallback de segurança
}

// Retorna valor do erro quando método finalizou. Este valor depende de tipoErro
real_t bisseccao (Polinomio p, real_t a, real_t b, int criterioParada, int *it, real_t *raiz, int modo)
{
    real_t hl, hu, hm, fhm, dxm;
    Double_t ulps;

    void (*calcPolinomio)(Polinomio, real_t, real_t*, real_t*);
    if (modo == 1) calcPolinomio = calcPolinomio_lento;
    else calcPolinomio = calcPolinomio_rapido;

    // Verifica existência de raiz
    calcPolinomio(p, a, &hl, &dxm);
    calcPolinomio(p, b, &hu, &dxm);
    if (hl * hu > 0) return -1;

    *it = 1;  // inicializa o contador
    while (*it < MAXIT) {

        hm = (a + b) / 2;
        calcPolinomio(p, hm, &fhm, &dxm);
        *raiz = hm;

        ulps = ulps_diff(a, b);
        if (criterioParada == 1 && fabs(b - a) <=  EPS) 
            return fabs(b - a);
        if (criterioParada == 2 && fabs(fhm) <= DBL_EPSILON) 
            return fabs(fhm);
        if (criterioParada == 3 && ulps.i <= ULPS) 
            return ulps.f;

        if (hl * fhm < 0) {
            b = hm;
            hu = fhm;
        } else {
            a = hm;
            hl = fhm;
        }

        (*it)++; // incrementa o contador
    }
    // Critérios de retorno caso o while termine sem atender critério de parada
    if (criterioParada == 1) 
        return fabs(b - a);
    if (criterioParada == 2) 
        return fabs(fhm);
    if (criterioParada == 3) 
        return ulps.f;

    return -1; // fallback de segurança
}