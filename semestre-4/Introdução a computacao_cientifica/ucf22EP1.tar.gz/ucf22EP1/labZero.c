#include <stdio.h>
#include <stdlib.h>
#include <fenv.h>

#include "utils.h"
#include "ZeroFuncao.h"
#include "DoubleType.h"


int main() {
    real_t a, b, x0;
    Polinomio pol;
    int it;
    real_t raiz, erro, tempo_inicial, tempo_final, tempo_execucao;

    Double_t criterio;

    scanf("%d", &pol.grau);
    
    pol.p = (real_t*) malloc((pol.grau + 1) * sizeof(real_t));
    if (pol.p == NULL) {
        printf("Erro na alocação de memória para o polinômio!\n");
        return 1;
    }

    for (int i = pol.grau; i >= 0; --i)
        scanf("%lf", &pol.p[i]);

    scanf("%lf %lf", &a, &b);
    x0 = (a + b) / 2;

    printf("RAPIDO\n\n");
    // TESTES FEITOS COM A FUNÇÃO DE CÁLCULO RAPIDO.
    fesetround(FE_DOWNWARD);

    for(int i = 1; i <= 3; i++){

        it = 0;
        tempo_inicial = timestamp();
        criterio.f = bisseccao(pol, a, b, i, &it, &raiz, 0);
        tempo_final = timestamp();
        tempo_execucao = tempo_final - tempo_inicial;
        printf("bissec %.15e %.15e %d %.8e\n", raiz, criterio.f, it, tempo_execucao);
    }

    for(int i = 1; i <= 3; i++){

        it = 0;
        tempo_inicial = timestamp();
        criterio.f = newtonRaphson(pol, b, i, &it, &raiz, 0);
        tempo_final = timestamp();
        tempo_execucao = tempo_final - tempo_inicial;
        printf("bissec %.15e %.15e %d %.8e\n", raiz, criterio.f, it, tempo_execucao);
    }

    printf("\nLENTO\n\n");
    // TESTES FEITOS COM A FUNÇÃO DE CÁLCULO LENTO.

    for(int i = 1; i <= 3; i++){

        it = 0;
        tempo_inicial = timestamp();
        criterio.f = bisseccao(pol, a, b, i, &it, &raiz, 1);
        tempo_final = timestamp();
        tempo_execucao = tempo_final - tempo_inicial;
        printf("bissec %.15e %.15e %d %.8e\n", raiz, criterio.f, it, tempo_execucao);
    }
    
    for(int i = 1; i <= 3; i++){

        it = 0;
        tempo_inicial = timestamp();
        criterio.f = newtonRaphson(pol, b, i, &it, &raiz, 1);
        tempo_final = timestamp();
        tempo_execucao = tempo_final - tempo_inicial;
        printf("bissec %.15e %.15e %d %.8e\n", raiz, criterio.f, it, tempo_execucao);
    }

    fesetround(FE_TONEAREST);
    free(pol.p);
    return 0;
}
